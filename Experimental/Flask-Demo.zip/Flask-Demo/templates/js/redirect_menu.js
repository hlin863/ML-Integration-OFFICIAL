function redirect_ci_history(){
    window.location.href = "http://localhost:8000/blog/ci_history/";
}